# Project Data  

How to use the data folders:

├── data.md
├── data/
├── data-raw/
└── inst/
     └── extdata/


1. Put the code used to download or create raw data files in the `data-raw/` folder

2. Put processed data in the `data/` folder

3. Put any data used for examples or testing in `inst/extdata/`

4. Document your data in `code/data.R`


For guidance on external data, please see: https://r-pkgs.org/data.html#sec-data-extdata

More Resources

1. Sharing data: http://bit.ly/data-4-sharing

2. Data in spreadsheets: http://bit.ly/data-in-sheets

3. Internal data: https://r-pkgs.org/data.html
