<!--
...make dated notes about changes to the project in this file in reverse
chronological order (i.e., most recent first). See examples below:
-->

# CHANGELOG
=============

## 2023-03-30

* Created ref/ folder

* Created ref/notebook.Rmd and ref/manuscript.Rmd

Source: https://swcarpentry.github.io/good-enough-practices-in-scientific-computing/
